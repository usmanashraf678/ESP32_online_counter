# CSS Flip Counter

[http://cnanney.com/journal/code/css-flip-counter-revisited/](http://cnanney.com/journal/code/css-flip-counter-revisited/)